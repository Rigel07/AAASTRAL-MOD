package com.astral.client;

import com.astral.AstralMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Modelo del cojin: almohadon mullido con cuatro borlas en las esquinas y un boton dorado. */
public final class PillowModel {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(AstralMod.MODID, "magic_pillow"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AstralMod.MODID, "textures/entity/magic_pillow.png");

    private static ModelPart cached;

    private PillowModel() {}

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 12.0F),
                PartPose.ZERO);
        root.addOrReplaceChild("puff0",
                CubeListBuilder.create().texOffs(0, 16).addBox(-1.5F, -2.5F, -1.5F, 3.0F, 5.0F, 3.0F),
                PartPose.offset(-7.5F, 0.0F, -5.5F));
        root.addOrReplaceChild("puff1",
                CubeListBuilder.create().texOffs(12, 16).addBox(-1.5F, -2.5F, -1.5F, 3.0F, 5.0F, 3.0F),
                PartPose.offset(7.5F, 0.0F, -5.5F));
        root.addOrReplaceChild("puff2",
                CubeListBuilder.create().texOffs(24, 16).addBox(-1.5F, -2.5F, -1.5F, 3.0F, 5.0F, 3.0F),
                PartPose.offset(-7.5F, 0.0F, 5.5F));
        root.addOrReplaceChild("puff3",
                CubeListBuilder.create().texOffs(36, 16).addBox(-1.5F, -2.5F, -1.5F, 3.0F, 5.0F, 3.0F),
                PartPose.offset(7.5F, 0.0F, 5.5F));
        root.addOrReplaceChild("button",
                CubeListBuilder.create().texOffs(48, 16).addBox(-0.5F, -3.0F, -0.5F, 1.0F, 1.0F, 1.0F),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 32);
    }

    private static ModelPart root() {
        if (cached == null) {
            cached = Minecraft.getInstance().getEntityModels().bakeLayer(LAYER);
        }
        return cached;
    }

    /** Dibuja el cojin (1 x 0,25 x 0,75 bloques a escala 1) centrado en el origen y plano. */
    public static void render(PoseStack poseStack, MultiBufferSource buffers, int light,
                              float sx, float sy, float sz) {
        poseStack.pushPose();
        poseStack.scale(-sx, -sy, sz);
        root().render(poseStack, buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)), light,
                OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
    }
}
