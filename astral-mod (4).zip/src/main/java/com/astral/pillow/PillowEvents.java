package com.astral.pillow;

import com.astral.AstralMod;
import com.astral.config.AstralConfig;
import com.astral.registry.ModEffects;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.BucketPickup;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** La logica de servidor de los cuatro modos de la almohada. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class PillowEvents {
    private static final float HOVER_SPEED = 0.03F;
    private static final float NORMAL_SPEED = 0.05F;

    /** Jugadores cuyo vuelo gestiona la almohada (para devolverles la normalidad despues). */
    private static final Set<UUID> MANAGED = new HashSet<>();
    private static final Set<UUID> REST_DONE = new HashSet<>();

    private PillowEvents() {}

    // --------------------------------------------------- cabeza: proteccion total

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player) || !PillowUtil.worn(player, EquipmentSlot.HEAD)) {
            return;
        }
        if (!AstralConfig.PILLOW_GUARD_ENABLED.get()) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        event.setCanceled(true);
        if (player.level() instanceof ServerLevel level && player.tickCount % 4 == 0) {
            level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 1.0D, player.getZ(),
                    8, 0.4D, 0.4D, 0.4D, 0.03D);
            level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.4D, player.getZ(),
                    1, 0.3D, 0.2D, 0.3D, 0.0D);
            level.playSound(null, player.blockPosition(), SoundEvents.WOOL_HIT, SoundSource.PLAYERS, 1.0F, 1.3F);
        }
    }

    // ---------------------------------------------------------- tick de servidor

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER
                || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        for (EquipmentSlot slot : PillowUtil.ARMOR_SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            if (PillowUtil.isPillow(stack)) {
                PillowUtil.ensureId(stack);
            }
        }
        boolean chest = PillowUtil.worn(player, EquipmentSlot.CHEST);
        boolean legs = PillowUtil.worn(player, EquipmentSlot.LEGS);
        boolean feet = PillowUtil.worn(player, EquipmentSlot.FEET);

        if (player.hasEffect(ModEffects.PILLOW_RIDE.get()) && !feet) {
            PillowActions.stopRide(player, false);
        }
        updateFlight(player, chest);

        if (chest && player.tickCount % 40 == 0 && player.getHealth() < player.getMaxHealth()) {
            player.heal(1.0F);
            player.serverLevel().sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.2D, player.getZ(),
                    1, 0.3D, 0.2D, 0.3D, 0.0D);
        }
        if (legs && player.tickCount % 2 == 0) {
            absorb(player, player.getItemBySlot(EquipmentSlot.LEGS));
        }
        tickRest(player);
        if (player.hasEffect(ModEffects.PILLOW_RIDE.get()) && player.tickCount % 2 == 0) {
            player.serverLevel().sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.1D, player.getZ(),
                    2, 0.5D, 0.05D, 0.5D, 0.01D);
        }
    }

    // -------------------------------------------- pecho y botas: flotar y volar

    private static void updateFlight(ServerPlayer player, boolean chest) {
        boolean ride = player.hasEffect(ModEffects.PILLOW_RIDE.get());
        float desired = ride ? AstralConfig.RIDE_SPEED.get().floatValue() : (chest ? HOVER_SPEED : 0.0F);
        UUID id = player.getUUID();
        Abilities abilities = player.getAbilities();

        if (desired > 0.0F && !player.isCreative() && !player.isSpectator()) {
            boolean dirty = false;
            if (!abilities.mayfly) {
                abilities.mayfly = true;
                dirty = true;
            }
            if (abilities.getFlyingSpeed() != desired) {
                abilities.setFlyingSpeed(desired);
                dirty = true;
            }
            if (!player.onGround() && !abilities.flying) {
                abilities.flying = true;
                dirty = true;
            }
            if (dirty) {
                player.onUpdateAbilities();
            }
            MANAGED.add(id);
        } else if (MANAGED.remove(id)) {
            if (!player.isCreative() && !player.isSpectator()) {
                abilities.mayfly = false;
                abilities.flying = false;
            }
            abilities.setFlyingSpeed(NORMAL_SPEED);
            player.onUpdateAbilities();
        }
    }

    // ------------------------------------------------------------------ dormir

    private static void tickRest(ServerPlayer player) {
        MobEffectInstance rest = player.getEffect(ModEffects.PILLOW_REST.get());
        UUID id = player.getUUID();
        if (rest == null) {
            REST_DONE.remove(id);
            return;
        }
        if (player.tickCount % 10 == 0) {
            player.serverLevel().sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 1.6D, player.getZ(),
                    2, 0.2D, 0.1D, 0.2D, 0.01D);
        }
        if (rest.getDuration() <= 3 && REST_DONE.add(id)) {
            PillowActions.finishRest(player);
        }
    }

    // ------------------------------------------ pantalones: bolsillo que absorbe

    private static void absorb(ServerPlayer player, ItemStack pillow) {
        ServerLevel level = player.serverLevel();
        PocketInventory pocket = PocketStorage.get(player.server).pocket(PillowUtil.ensureId(pillow));
        Vec3 target = player.position().add(0.0D, 0.8D, 0.0D);

        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, player.getBoundingBox().inflate(AstralConfig.POCKET_RADIUS.get()),
                e -> e.isAlive() && !e.hasPickUpDelay())) {
            Vec3 toPlayer = target.subtract(item.position());
            if (toPlayer.length() < 2.0D) {
                ItemStack original = item.getItem();
                ItemStack rest = pocket.add(original);
                if (rest.isEmpty()) {
                    level.sendParticles(ParticleTypes.POOF, item.getX(), item.getY() + 0.2D, item.getZ(), 4, 0.1D, 0.1D, 0.1D, 0.02D);
                    level.playSound(null, item.blockPosition(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.4F, 1.8F);
                    item.discard();
                } else if (rest.getCount() != original.getCount()) {
                    item.setItem(rest);
                }
            } else {
                item.setDeltaMovement(item.getDeltaMovement().scale(0.5D).add(toPlayer.normalize().scale(0.3D)));
                item.hasImpulse = true;
            }
        }

        // agachado, tambien absorbe el agua cercana (como una esponja) y la guarda en cubos
        if (player.isShiftKeyDown() && player.tickCount % 8 == 0) {
            BlockPos center = player.blockPosition();
            int taken = 0;
            for (BlockPos pos : BlockPos.betweenClosed(center.offset(-4, -3, -4), center.offset(4, 3, 4))) {
                if (taken >= 3 || !pocket.hasEmptySlot()) {
                    break;
                }
                if (!level.getFluidState(pos).is(FluidTags.WATER)) {
                    continue;
                }
                BlockState state = level.getBlockState(pos);
                if (state.getBlock() instanceof BucketPickup pickup) {
                    ItemStack bucket = pickup.pickupBlock(player, level, pos, state);
                    if (bucket.is(Items.WATER_BUCKET)) {
                        pocket.add(bucket);
                        taken++;
                        level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                8, 0.3D, 0.3D, 0.3D, 0.1D);
                    }
                }
            }
            if (taken > 0) {
                level.playSound(null, player.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 0.6F, 1.4F);
            }
        }
    }

    // --------------------------------------------------------- limpieza de estado

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        MANAGED.remove(event.getEntity().getUUID());
        REST_DONE.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        MANAGED.remove(event.getEntity().getUUID());
        REST_DONE.remove(event.getEntity().getUUID());
    }
}
