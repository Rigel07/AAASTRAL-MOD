package com.astral.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Teclas de la almohada magica (se pueden cambiar en Opciones > Controles). */
public final class PillowKeys {
    public static final String CATEGORY = "key.categories.astral";

    public static final KeyMapping SLEEP = new KeyMapping("key.astral.pillow_sleep",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, CATEGORY);
    public static final KeyMapping POCKET = new KeyMapping("key.astral.pillow_pocket",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);
    public static final KeyMapping RIDE = new KeyMapping("key.astral.pillow_ride",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);

    private PillowKeys() {}
}
