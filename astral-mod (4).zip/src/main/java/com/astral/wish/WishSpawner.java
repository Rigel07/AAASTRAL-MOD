package com.astral.wish;

import com.astral.AstralMod;
import com.astral.config.AstralConfig;
import com.astral.registry.ModEntities;
import com.astral.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hace caer deseos del cielo cerca de los jugadores del Overworld, y a veces una Lluvia de Deseos. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class WishSpawner {
    private static final int SHOWER_SECONDS = 30;

    /** Ultimo dia en el que se decidio si habia lluvia (se tira el dado una vez por noche). */
    private static long lastRollDay = -1L;
    private static int showerSeconds = 0;

    private WishSpawner() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.level.isClientSide()
                || !(event.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD
                || level.getGameTime() % 20L != 0L) {
            return;
        }
        rollShower(level);

        if (showerSeconds > 0) {
            showerSeconds--;
            for (ServerPlayer player : level.players()) {
                if (!player.isSpectator()) {
                    spawnNear(level, player, pickKind(level, true), true);
                    spawnNear(level, player, pickKind(level, true), true);
                }
            }
        }

        int interval = Math.max(1, AstralConfig.WISH_INTERVAL_SECONDS.get());
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator() || level.random.nextInt(interval) != 0) {
                continue;
            }
            int nearby = level.getEntitiesOfClass(WishEntity.class, new AABB(player.blockPosition()).inflate(64.0D)).size();
            if (nearby >= AstralConfig.MAX_NEARBY_WISHES.get()) {
                continue;
            }
            spawnNear(level, player, pickKind(level, false), false);
        }
    }

    /** Al empezar cada noche, con cierta probabilidad, cae una Lluvia de Deseos. */
    private static void rollShower(ServerLevel level) {
        long time = level.getDayTime() % 24000L;
        long day = level.getDayTime() / 24000L;
        if (day != lastRollDay && time >= 13000L && time < 23000L) {
            lastRollDay = day;
            if (level.random.nextDouble() < AstralConfig.SHOWER_CHANCE.get()) {
                startShower(level);
            }
        }
    }

    public static void startShower(ServerLevel level) {
        showerSeconds = SHOWER_SECONDS;
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("message.astral.shower_start"), false);
        for (ServerPlayer player : level.players()) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.WISH_SHOWER.get(),
                    SoundSource.AMBIENT, 3.0F, 1.0F);
        }
    }

    private static boolean isDay(ServerLevel level) {
        return level.getDayTime() % 24000L < 12000L;
    }

    /** Eleccion ponderada: el dorado solo cae de dia y el oscuro solo de noche (salvo en las lluvias). */
    private static WishKind pickKind(ServerLevel level, boolean ignoreTime) {
        boolean day = isDay(level);
        int total = 0;
        for (WishKind kind : WishKind.values()) {
            total += weightOf(kind, day, ignoreTime);
        }
        int roll = level.random.nextInt(total);
        for (WishKind kind : WishKind.values()) {
            roll -= weightOf(kind, day, ignoreTime);
            if (roll < 0) {
                return kind;
            }
        }
        return WishKind.GREEN;
    }

    private static int weightOf(WishKind kind, boolean day, boolean ignoreTime) {
        if (!ignoreTime) {
            if (kind == WishKind.GOLD && !day) {
                return 0;
            }
            if (kind == WishKind.DARK && day) {
                return 0;
            }
        }
        return kind.weight;
    }

    private static void spawnNear(ServerLevel level, ServerPlayer player, WishKind kind, boolean quiet) {
        RandomSource random = level.random;
        double angle = random.nextDouble() * Math.PI * 2.0D;
        double distance = 6.0D + random.nextDouble() * (quiet ? 22.0D : 14.0D);
        int x = (int) Math.floor(player.getX() + Math.cos(angle) * distance);
        int z = (int) Math.floor(player.getZ() + Math.sin(angle) * distance);
        if (!level.hasChunkAt(new BlockPos(x, player.getBlockY(), z))) {
            return;
        }
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int y = Math.min(level.getMaxBuildHeight() - 5,
                Math.max(player.getBlockY(), ground) + AstralConfig.WISH_FALL_HEIGHT.get());
        spawn(level, kind, x + 0.5D, y, z + 0.5D);
        if (!quiet) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.WISH_SPAWN.get(),
                    SoundSource.AMBIENT, 2.0F, kind.rare ? 0.7F : 1.0F);
            if (kind.rare) {
                player.displayClientMessage(Component.translatable("message.astral.wish_rare_falling." + kind.id()), true);
            }
        }
    }

    public static WishEntity spawn(ServerLevel level, WishKind kind, double x, double y, double z) {
        WishEntity wish = ModEntities.WISH.get().create(level);
        if (wish == null) {
            return null;
        }
        wish.setKind(kind);
        wish.moveTo(x, y, z, 0.0F, 0.0F);
        level.addFreshEntity(wish);
        return wish;
    }
}
