package com.astral.pillow;

import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** El bolsillo magico: 162 huecos (3 paginas de 54). */
public class PocketInventory implements Container {
    public static final int SIZE = 162;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
    private final Runnable onChange;

    public PocketInventory(Runnable onChange) {
        this.onChange = onChange;
    }

    /** Guarda lo que cabe y devuelve el resto. */
    public ItemStack add(ItemStack stack) {
        ItemStack rest = stack.copy();
        boolean changed = false;
        for (int i = 0; i < SIZE && !rest.isEmpty(); i++) {
            ItemStack current = items.get(i);
            if (!current.isEmpty() && ItemStack.isSameItemSameTags(current, rest)) {
                int space = current.getMaxStackSize() - current.getCount();
                if (space > 0) {
                    int moved = Math.min(space, rest.getCount());
                    current.grow(moved);
                    rest.shrink(moved);
                    changed = true;
                }
            }
        }
        for (int i = 0; i < SIZE && !rest.isEmpty(); i++) {
            if (items.get(i).isEmpty()) {
                int moved = Math.min(rest.getMaxStackSize(), rest.getCount());
                items.set(i, rest.split(moved));
                changed = true;
            }
        }
        if (changed) {
            setChanged();
        }
        return rest;
    }

    public boolean hasEmptySlot() {
        for (ItemStack stack : items) {
            if (stack.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        ContainerHelper.saveAllItems(tag, items);
        return tag;
    }

    public void load(CompoundTag tag) {
        ContainerHelper.loadAllItems(tag, items);
    }

    @Override
    public int getContainerSize() {
        return SIZE;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) {
            setChanged();
        }
        return result;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) {
            stack.setCount(getMaxStackSize());
        }
        setChanged();
    }

    @Override
    public void setChanged() {
        onChange.run();
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void clearContent() {
        items.clear();
        setChanged();
    }
}
