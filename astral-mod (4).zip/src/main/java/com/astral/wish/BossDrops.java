package com.astral.wish;

import com.astral.AstralMod;
import com.astral.registry.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Los jefes tambien guardan almas antiguas: otra forma de conseguir esencias raras. */
@Mod.EventBusSubscriber(modid = AstralMod.MODID)
public final class BossDrops {
    private BossDrops() {}

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel level)) {
            return;
        }
        int r = level.random.nextInt(2);
        if (entity instanceof WitherBoss) {
            drop(event, ModItems.ESSENCE_DARK.get(), 1 + r);
            drop(event, ModItems.ESSENCE_RED.get(), 2);
        } else if (entity instanceof EnderDragon) {
            drop(event, ModItems.ESSENCE_GOLD.get(), 1 + r);
            drop(event, ModItems.ESSENCE_VIOLET.get(), 2);
        } else if (entity instanceof Warden) {
            drop(event, ModItems.ESSENCE_DARK.get(), 1);
            drop(event, ModItems.ESSENCE_VIOLET.get(), 1);
        } else if (entity instanceof ElderGuardian) {
            drop(event, ModItems.ESSENCE_GREEN.get(), 1 + r);
            drop(event, ModItems.ESSENCE_YELLOW.get(), 1);
        }
    }

    private static void drop(LivingDropsEvent event, Item item, int count) {
        LivingEntity entity = event.getEntity();
        event.getDrops().add(new ItemEntity(entity.level(), entity.getX(), entity.getY() + 0.5D, entity.getZ(),
                new ItemStack(item, count)));
    }
}
