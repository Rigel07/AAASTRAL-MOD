package com.astral.item;

import com.astral.wish.WishEntity;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Brujula de Deseos: al usarla indica el deseo mas cercano (color, distancia y direccion) y marca el camino con chispas. */
public class WishCompassItem extends Item {
    private static final double RANGE = 160.0D;
    private static final String[] DIRECTIONS = {"n", "ne", "e", "se", "s", "sw", "w", "nw"};

    public WishCompassItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel serverLevel) {
            locate(serverLevel, player);
        }
        player.getCooldowns().addCooldown(this, 40);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private void locate(ServerLevel level, Player player) {
        List<WishEntity> wishes = level.getEntitiesOfClass(WishEntity.class, player.getBoundingBox().inflate(RANGE));
        WishEntity nearest = wishes.stream()
                .min(Comparator.comparingDouble(w -> w.distanceToSqr(player)))
                .orElse(null);
        if (nearest == null) {
            player.displayClientMessage(Component.translatable("message.astral.compass_none").withStyle(ChatFormatting.GRAY), true);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 0.8F, 0.8F);
            return;
        }
        double dx = nearest.getX() - player.getX();
        double dz = nearest.getZ() - player.getZ();
        double bearing = (Math.toDegrees(Math.atan2(dz, dx)) + 90.0D + 360.0D) % 360.0D;
        String direction = DIRECTIONS[(int) Math.round(bearing / 45.0D) % 8];
        int distance = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        int height = (int) Math.round(nearest.getY() - player.getY());

        player.displayClientMessage(Component.translatable("message.astral.compass_found",
                Component.translatable("wish.astral." + nearest.getKind().id()),
                distance, Component.translatable("direction.astral." + direction), height), true);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.4F);

        // estela de chispas hacia el deseo
        Vec3 from = player.getEyePosition();
        Vec3 toward = nearest.position().subtract(from).normalize();
        for (int i = 2; i < 16; i++) {
            Vec3 p = from.add(toward.scale(i * 0.9D));
            level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.astral.wish_compass").withStyle(ChatFormatting.GRAY));
    }
}
