package com.astral.pillow;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: el jugador ha pulsado una de las teclas de la almohada. */
public record PillowActionPacket(int action) {

    public static void encode(PillowActionPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.action());
    }

    public static PillowActionPacket decode(FriendlyByteBuf buf) {
        return new PillowActionPacket(buf.readVarInt());
    }

    public static void handle(PillowActionPacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                PillowActions.perform(player, packet.action());
            }
        });
        ctx.setPacketHandled(true);
    }
}
