package com.astral.client;

import com.astral.pillow.PocketMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** Pantalla del bolsillo magico: un cofre grande de tres paginas. */
public class PocketScreen extends AbstractContainerScreen<PocketMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("textures/gui/container/generic_54.png");

    public PocketScreen(PocketMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageHeight = 114 + PocketMenu.ROWS * 18;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void init() {
        super.init();
        this.addRenderableWidget(Button.builder(Component.literal("<"), button -> click(0))
                .bounds(this.leftPos + this.imageWidth - 44, this.topPos + 4, 14, 12).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), button -> click(1))
                .bounds(this.leftPos + this.imageWidth - 28, this.topPos + 4, 14, 12).build());
    }

    private void click(int id) {
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, id);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        this.renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = (this.width - this.imageWidth) / 2;
        int y = (this.height - this.imageHeight) / 2;
        graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, PocketMenu.ROWS * 18 + 17);
        graphics.blit(TEXTURE, x, y + PocketMenu.ROWS * 18 + 17, 0, 126, this.imageWidth, 96);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        super.renderLabels(graphics, mouseX, mouseY);
        String page = (this.menu.getPage() + 1) + "/" + PocketMenu.PAGES;
        graphics.drawString(this.font, page, this.imageWidth - 48 - this.font.width(page), 6, 0x404040, false);
    }
}
